%% AE Source Location
% Picks AE data (stored in folder sg2) using trained neural network. Data
% is then located using Time Difference of Arrival

%% Version
% Version 1.0, 16th January 2019. Thomas King
%   - First Version

%% Parameter Customisation
% Below are the suggested parameters to be modified. I don't recommend
% changing any of the code outside of these parameters.

clear all; close all

% This is the name of the picking model. I recommend to use folder names to
% avoid confusion as this testname is required when using the locating code
testname = 'DDS_NSA3_20MPa';

%For use with seg2 data
datafolder = 'sg2'; 

figon = 1; % Display figures. 1 (on), 0 (off)
location = 1; % Locate data. 1 (on), 0 (off)

nPick = 4; % Minimum number of picks for source location

% Resamples waveforms to a shorter length. It can increase the speed of the
% code but time resolution is lost.
sigsamp = 4096;

% Minimum arrival time. Recommended at 10% of signal length
minpick = round(sigsamp/10);

%% Compile data

% Find origin time
dirls = dir([datafolder,'/*seg2']);
index = 0; clear event
for i = 1:size(dirls,1)
    event{i,1} = dirls(i).name;
    filename = event{i};
    sourcelocs{i,1} = filename;
    filename([9,16,20:end]) = '-';
    formatIn = 'yyyymmdd-HHMMSS-fff---------';
    tempi(i,1) = datenum(filename,formatIn);
end

% Find receiver positions
if exist('recloc') == 0
    cd(datafolder)
    filename = event{1};
    [tracce,SR,Shot,X,n_samples,RL] = leggisg2(char(filename));
    Ts = SR;
    Fs = 1/SR;
    for j = 1:length(RL)
        rec = strsplit(char(RL(j,:)));
        recloc(j,1) = str2num(rec{3}); % NED to XYZ
        recloc(j,2) = str2num(rec{2});
        recloc(j,3) = str2num(rec{4});
    end
    if max(max(recloc)) > 0.1
        recloc = recloc./1000;
    end
    cd ..
    save recloc.mat recloc
else
    load recloc.mat
end

% Load velocity model. If it cannot find, sample velocity is set to 5500
try
ls = dir('*velocity model.csv');
velmodimport; clear velwin
for i = 1:size(velocitymodel,1)
    velwin(i,1) = datenum(velocitymodel(i,7),velocitymodel(i,8),velocitymodel(i,9),...
        velocitymodel(i,10),velocitymodel(i,11),velocitymodel(i,12));
    velwin(i,2) = datenum(velocitymodel(i,13),velocitymodel(i,14),velocitymodel(i,15),...
        velocitymodel(i,16),velocitymodel(i,17),velocitymodel(i,18));
    velwin(i,3) = velocitymodel(i,1);
    velwin(i,4) = velocitymodel(i,3);
end
catch
    velwin = [0, 1000000000, 5500, 1];
end

% Angles between receivers for velocity anisotropy
angles = [];
for i = 1:length(recloc)
    for j = 1:length(recloc)
        [~,ang] = rangeangle(recloc(i,:)',recloc(j,:)');
        ang = ang(2);
        angles(i,j) = ang;
    end
end

% Reset workspace
sources = []; error = [];
i = 1;
load(char(['pkmodel-',char(testname),'.mat']),'p_mul','t_mul','dtdnn_net')
pktimes = cell(size(recloc,1),9,length(event));

%% Picking and Source Location
i = i - 1;
bindex = 0; fstp2 = 0;
while i ~= size(event,1)
    
    % Reset
    pk = cell(size(recloc,1),9); sigM = ones(size(recloc,1),1);
    pk(:,:) = num2cell(NaN);
    sourcestore = cell(1,5);
    global cvel
    cvel = []; filename = [];
    Ts = 1/Fs;
    
    % Load file and set current velocity
    i = i + 1;
    display(['Event ',num2str(i)])
    filename = event{i};
    etime = tempi(i);
    ind = find(velwin(:,1) < etime & velwin(:,2) > etime);
    if isempty(ind) == 1
        continue
    else
        global cvel
        cvel = velwin(ind(1),:);
        cd(datafolder) % Load file
        try
            [tracce,SR,Shot,X,n_samples,RL] = leggisg2(filename);
       catch
           cd ..
           pktimes(:,:,i) = pk;
            sourcestore{1,1} = filename;
            sourcestore(1,2:5) = num2cell(NaN);
            sourcelocs(i,1:5) = sourcestore;
            continue
        end
        signal = tracce; %(:,rec)
        cd ..
    end
    
    % Picking
    
    % Sort waveforms according to amplitude
    rsig = max(signal(1:length(signal)/2,:));
    [~,ordersize] = sort(rsig,'descend');
    try
        if isempty(ordersize) == 1
            pktimes(:,:,i) = pk;
            sourcestore{1,1} = filename;
            sourcestore(1,2:5) = num2cell(NaN);
            sourcelocs(i,1:5) = sourcestore;
            continue
        end
    catch
        [~,ordersize] = sort(rsig,'descend');
    end
    
    % Begin
    for o = 1:length(ordersize)
        
        % Reset
        Ts = 1/Fs;
        r = ordersize(o);
        display(num2str(o))
        sig= resample(signal(:,r),sigsamp,length(signal(:,r)));
        Ts = Ts*(length(signal(:,r))/sigsamp);
        
        % Get neural network input parameters
        try
           % tic
            IFcontent
            %toc
        catch
            pk{r,1} = filename;
            pk{r,2} = NaN;
            pk(r,3:9) = num2cell(NaN);
            continue
        end
        p1 = [con2seq(cc(1:length(sn))');con2seq(esig(1:length(sn)));...
            con2seq(sn(1:length(sn)));];
        
        % Get arrival time
        try
            pick_output_3
        catch
            pk{r,1} = filename;
            pk{r,2} = NaN;
            pk(r,3:9) = num2cell(NaN);
            continue
        end
        pk1 = ind(1);
        
        % Store arrival times
        if pk1 > minpick
            try
                fill_pk                
                if pk{r,3} > 800 % Clipped data
                    pk = cell(size(recloc,1),9); sigM = ones(size(recloc,1),1);
                    pk(:,:) = num2cell(NaN);
                    sourcestore = cell(1,5);
                    pktimes(:,:,i) = pk;
                    sourcestore{1,1} = filename;
                    sourcestore(1,2:5) = num2cell(NaN);
                    sourcelocs(i,1:5) = sourcestore;
                    i = i+1;
                    fstp2 = 1;
                end
            catch
                pk{r,1} = filename;
                pk{r,2} = NaN;
                pk(r,3:9) = num2cell(NaN);
                continue
            end
        else
            pk{r,1} = filename;
            pk{r,2} = NaN;
            pk(r,3:9) = num2cell(NaN);
            continue
        end
        
        % Some traces don't work, this is part of a workaround
        if fstp2 == 1
            fstp2 = 0;
            break
        end
        
    end
    
    % If arrival time is after maximum, set time to NaN
    TOA = cell2mat(pk(:,2));
    test = (sigM-TOA);
    pk(test<0 | isnan(test) == 1,:) = num2cell(NaN);
    test(test<0 | isnan(test) == 1) = NaN;
    TOA(test<0 | isnan(test) == 1) = NaN;
    pktimes(:,:,i) = pk;
    
    % Locate AE

    % Checks for minimum picks and if locating is turned on
    if sum(cell2mat(pk(:,2))) > size(recloc,1)-nPick || location == 0
        sourcestore{1,1} = filename;
        sourcestore(1,2:5) = num2cell(NaN);
        sourcelocs(i,1:5) = sourcestore;
        continue
    end

    % Reset
    restore = []; sourceopts = [];
    p=1;
    
    % Source inversion
        [answer,res] = localize2(0,[0,0,0],TOA,...
            recloc,cvel,angles);
        restore(p,:) = res; % Location residual
        sourceopts(p,:) = answer % Source location
    global calcdelays
    global BUSHDelays
    
    try
        ind = find(restore == min(restore));
        res = restore(ind(1));
        answer = sourceopts(ind(1),:);
    catch
        sourcestore{1,1} = filename;
        sourcestore(1,2:5) = num2cell(NaN);
        sourcelocs(i,1:5) = sourcestore;
        continue
    end
    
    % Plots waveforms and arrival times
     if ismember(i,1:1:length(event)) == 1 && figon == 1
        [~,order] = sort(cell2mat(pk(:,2)),'ascend');
        stp = max(max(abs(signal)));
        figure(2); yyaxis left; cla
        for jj = 1:length(order)
            Ts = 1/Fs;
            try
                csig = signal(:,order(jj));
                plot(csig+(stp*(jj-1)),'k-'); hold on;
                scatter(round(pk{order(jj),2}/Ts),(stp*(jj-1)),'ro','filled')
            end
        end
        drawnow
     end
    
    % Compile results
    x0 = answer;
    sources = [sources;x0]; % Source location
    
    numpicks(i) = size(recloc,1)-ind(1); % Number of picks
    residual(i) = res; % Location residual
    snrrat(i) = max(cell2mat(pk(:,3))); % Signal to noise ratio
    
    sourcelocs{i,1} = filename; % Position
    sourcelocs{i,2} = x0(1);
    sourcelocs{i,3} = x0(2);
    sourcelocs{i,4} = x0(3);
    sourcelocs{i,5} = tempi(i);
    
    % Plot source locations
    if ismember(i,1:1:size(event,1)) == 1 && figon == 1
        figure(4); cla; hold on
       try
%             ind = find(snrrat > 2 & numpicks >= 9 & snrrat < 300 & residual < 2e-6);% & residual > .01e-8);
%             sources = cell2mat(sourcelocs(ind,2:4));
             scatter3(sources(:,1),sources(:,2),sources(:,3),4,'ko','filled')
            alpha(0.3334)
            scatter3(sources(end,1),sources(end,2),sources(end,3),10,'ro','filled')
       catch
           continue
       end
        xlim([-0.02 0.02])
        ylim([-0.02 0.02])
        zlim([-0.05 0.05])

        pbaspect([4 4 10])
        ax = gca;               % get the current axis
        ax.Clipping = 'on';
        view([0 0])
        camproj('perspective')
        xlabel('x')
        ylabel('y')
        xhandle = get(gca, 'Xlabel');
        yhandle = get(gca, 'Ylabel');
        thandle = get(gca, 'Title');
        set([xhandle; yhandle; thandle], 'units', 'normal');
        drawnow
    end
end

%% Cleanup and saving

display('Removing NaN and Inf')
ind = find(sum(isnan(cell2mat(sourcelocs(:,2:4))'))' +sum(isinf(cell2mat(sourcelocs(:,2:4))'))' == 0);
sourcelocs = sourcelocs(ind,:); % Sets events to only those found in the cylinder
pktimes = pktimes(:,:,ind);
tempi = tempi(ind);
numpicks= numpicks(ind);
residual= residual(ind);
snrrat = snrrat(ind);

% Removes events located outside of the sample. This is set for a 4x10 cm
% cylinder
display('Removing External Events')
% Remove external events
[X1 Y1 Z1] = cylinder(max([max(recloc(:,1)) max(recloc(:,2))])); % Makes a cylinder with radius
Z1(2,:) = 0.1; % Sets cylinder height
shp = surf2patch(X1,Y1,Z1); % Makes it into a patch
X = shp.vertices(:,1);
Y = shp.vertices(:,2);
Z = shp.vertices(:,3)-max(recloc(:,3)); % Puts into the correct place
shp = alphaShape(X,Y,Z,1,'HoleThreshold',10000); % Makes it into a shape
ind = find(inShape(shp,cell2mat(sourcelocs(:,2)),cell2mat(sourcelocs(:,3)),cell2mat(sourcelocs(:,4))) == 1);
sourcelocs = sourcelocs(ind,:); % Sets events to only those found in the cylinder
pktimes = pktimes(:,:,ind);
tempi = tempi(ind);
numpicks= numpicks(ind);
residual= residual(ind);
snrrat = snrrat(ind);

save pktimes_ml.mat pktimes; save sourceloc_ml.mat sourcelocs; save tempi_ml.mat tempi;
save error_ml.mat numpicks residual snrrat